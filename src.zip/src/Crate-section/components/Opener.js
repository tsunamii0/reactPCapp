import PartPicker from "..";


const Opener = () => {
    return (
      <div className="openerdiv">
        <h1 className="cratename">Starter Crate ($120)</h1>
        <PartPicker></PartPicker>
      </div>
    );
  };

export default Opener